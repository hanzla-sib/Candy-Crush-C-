#pragma once

#include "game_play.h"
//#include "gaming_mode.h"

#include "util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

class player
{
	public:
	char player_name[200];
	game mygame;
	

	public:
	player();
	void get_player_name();
};