#pragma once

// #include "player.h"
// #include "game_play.h" 


#include "util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

class game_mode
{
    public:
	//making the function pure virtual as game mode wont exist on its own
    int current_level = 0;
    int levels = 3 ;
    int score_limit [3];
	float multiplier[3];
	float bar_height;
	virtual int function(int &timer ,int &score) = 0;
	virtual void bar(int score,int height) = 0 ;
	virtual void display() = 0;
}; 
class normal_mode : public game_mode
{
    public:
    normal_mode();
    int function(int &timer ,int &score);
    void bar(int score,int height);
	void display();
};
class time_trial_mode : public game_mode
{
    //In time trial mode bar is half way filled on start
    //with the passage of time bar will get finisehd but if he matches gems the bar will get filled up
    public:
	
	int increase = 0;
	float decrease = 0;
    float timely_decrease[3];
	time_trial_mode();
    int function(int &timer ,int &score);
    void bar(int score,int height);
	void display();
	
};
