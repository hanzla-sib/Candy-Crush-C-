#include "player.h"

#include "util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;


player :: player()
{
	mygame.myplayer = this;
}
void player ::  get_player_name()
{
	cout<<"Input theeeee Player Name"<<endl;
	cin.getline(player_name,200);
}