#include "gaming_mode.h"

#include "util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

normal_mode :: normal_mode()
{
	bar_height = 0 ;    // black bar
	current_level = 0;  //level starts from 1
	score_limit[0] = 75;// score reach to clear level and reach 2nd level
	score_limit[1] = 800;//score reach to 3rd level and clear 2nd level
	score_limit[2] = 4000;//  clear level 3 and reach 4 to infinity

	multiplier[0]=1;
	multiplier[1]=2;
	multiplier[2]=3;
}
int normal_mode :: function(int &timer ,int &score)
{
	if(score < score_limit[current_level])
	{
		timer++;
		return 0;
		//where 0 mean everything fine
	}
	else
	{
		current_level++;
		if(current_level>4)
		{
			return 1;               //if level increases from 4 then game stops..........................................
		}
		else
			return 0;
		
	}
}
void normal_mode :: bar(int score,int height)
{
	int temp_score = score - score_limit[current_level-1]*current_level; 
	bar_height = (float)(temp_score)/score_limit[current_level];
	bar_height = bar_height * (height - 550 - 50) ;
	DrawRectangle(15*70+14*10+20+50 , 550 , 80 , bar_height ,colors[BLUE_VIOLET]);
}
void normal_mode :: display()                          					//code for display strings.......................
{
	DrawString(800, 900-25 , 1400, 900,"Normal Mode", colors[YELLOW]);
	DrawString(800, 900-55 , 1400, 900,"Level" + Num2Str(current_level +1 ), colors[YELLOW]);

}

time_trial_mode :: time_trial_mode()
{  															//time trial mode........................
	bar_height = (900 - 550 - 50)/2 ;
	
	current_level = 0;
	score_limit[0] = 200;
	score_limit[1] = 400;
	score_limit[2] = 600;

	multiplier[0]=1;
	multiplier[1]=2;
	multiplier[2]=3;

	timely_decrease[0] = 1.5;
	timely_decrease[1] = 3;
	timely_decrease[2] = 4.5;

}
int time_trial_mode :: function(int &timer ,int &score)
{
	if(timer > 0)                                             					//when timer > 0 then time their is decrement in time................
	{
			timer--;
			decrease++;
		
		if(bar_height >= 900 - 550 - 50)                                                    	 // when ever bar cross this height their will be incrment in the level.............and timer of 120
		{
			current_level++;
			timer = 120;
		}
		else if(bar_height <= 0)                                                            		  // if bar height less then zero game over......................
		{
			return 1;
		}
		//where 0 mean everything fine
	}
	else if(timer <= 0)                                                                		        // or if timer become zero game also over.....................
	{
		return 1;
		//where 1 means termination from here
	}    
}
void time_trial_mode :: bar(int score,int height)                                                              // displaing bar...................
{
	float temp_increase = (float)(score)/score_limit[current_level];
	temp_increase = temp_increase * (height - 550 - 50) ;
	bar_height = (900 - 550 - 50)/2 + temp_increase - decrease*timely_decrease[current_level];
	DrawRectangle(15*70+14*10+20+50 , 550 , 80 , bar_height ,colors[BLUE_VIOLET]);
	cout<<"Decrease "<<decrease<<" .. "<<decrease*timely_decrease[current_level]<<endl;
}
void time_trial_mode :: display()                      							  	 // display for time trial mode...................................
{				
	DrawString(800, 900-25 , 1400, 900,"Time Trial Mode", colors[YELLOW]);
	DrawString(800, 900-55 , 1400, 900,"Level" + Num2Str(current_level + 1), colors[YELLOW]);
}
