#pragma once
class player;
// #include "player.h"
#include "gaming_mode.h"


#include "util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

enum GameState { // Use to check different states of game...
	Start,
	Ready,
	Paused,
	Settings,
	Levels,
	Game_Over,
	High_score,
	HowToPlay,
	PlayerProfile,
	MainMenu,
	GameModeSelection
};


class game
{
    public:
    
	player * myplayer;
	game_mode * mygamemode;
	int gamemode; // 0 for normal mode and 1 for time trial mode
	int load_y = 440;
	int save_y = 510;

	int buttons_radius = 20;
			
	int height = 900;
    int width = 1400;

	int high_score[4];
	int hint_x = 15*70+14*10+20+50+100;
	int hint_y = 120;
	int levels_x = 15*70+14*10+20+50+100;
	int levels_y = 190;
	int high_score_x = 15*70+14*10+20+50+100;
	int high_soore_y = 270;
	int settings_x = 15*70+14*10+20+50+100;
	int settings_y = 360;
	int how_to_play_x = width/3 + 200 ;
	int how_to_play_y = height - 2*height/3 + 150- 7;
	int player_profile_x = width/3 + 200;
	int player_profile_y = height - 2*height/3 + 100- 7;
	
	
	int Array[10][15];
    int clickx;
    int clicky;
    int setcolor, psetcolor;
    int timerdisplay;
	int score;
    GameState gamestate = Start;

    public:
	game();
	int Random();
	float Distance(float x1, float y1, float x2, float y2);
	void Pixels2Cell(int px, int py, int & cx, int &cy);
	void update_highscore();
	void save_game_state();
	void load_game_state();
	void decorating_game_screen();
	void decorating_game_over();
	void decorating_highscore();
	void decorating_hint();
	void decorating_levels();
	void decorating_player_profile();
	void decorating_How_to_play();
	void decorating_settings();
	void decorating_main_menu();
	
	
	void playgame();
	void GetCookie(int Array[10][15]);
	void autofalling(int Array[10][15]);
	void autofillingafterfalling(int Ck[10][15]);
	int autocrushing(int Arr[10][15]);
	void mainstart(int Array[10][15]);
	void swapping(int movedx,int movedy);
};
