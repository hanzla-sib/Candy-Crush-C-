#include "game_play.h"
#include "player.h"
#include "util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;



game :: game()
{
	//myplayer = NULL;
	mygamemode = new normal_mode();                                                    //class game mode from gaming_mde h file
	timerdisplay = 0 ;
	gamemode = 0 ;
	for(int i=0;i<4;i++)
	{
		high_score[i]=0;
	}
}
float game :: Distance(float x1, float y1, float x2, float y2) 
{
	return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}
int game :: Random() 											// generating random
{
	int x;
	x=rand()%5;  
	return x; 
}
void game :: Pixels2Cell(int px, int py, int & cx, int &cy)
{  
	cx=(px-80)/80;
	cy=py/80;
}	
void game :: update_highscore()									//code for updating high scoresssssss...........................
{
	for (int i = 0; i < 4; i++)
	{
		if(score>high_score[i])
			{
				for(int j = i; j < 4; j++)
					high_score[j]=high_score[j-1];
				high_score[i]=score;
				break;
			}
	}
}
void game :: decorating_game_screen()											// decorating game screen.........................
{
	int width_division = width / 3;


		//Colouring Boxes
		DrawRectangle(0,0,width_division,70,colors[BLACK]);
		//Printing the current timer
		DrawRectangle(width_division * 2,0,width-2*width_division,70,colors[BLACK]);
		//Printing the Current Score
		DrawString(80, height - 25, width, height,"Score  : " + Num2Str(score), colors[YELLOW]);
		DrawString(80, height - 55, width, height,"Timer : " + Num2Str(timerdisplay), colors[YELLOW]);
		
		//Colouring Boxes
		DrawRectangle(width_division,0,width_division,70,colors[BLACK]);
		DrawString(400, height - 40, width, height,"DESI CANDUY CRUSH 5.0", colors[YELLOW]);
		

		DrawRectangle(1040 - 20,10,190,50,colors[BROWN]);
		DrawString(1040, height - 40, width, height,"MAIN MENU", colors[YELLOW]);
		
		
		
		int box_width = 70;
		int box_height = 70;
		int box_x = width -70;
		int box_y = 0;

		DrawRectangle(width-70,0,70,70,colors[BROWN]);
		if(gamestate == Ready) 												//making of pause mod..................
		{
			//Draw Pause Button
			DrawRectangle(box_x+15,10,15,40,colors[YELLOW]);
			DrawRectangle(box_x+box_width-15-15,10,15,40,colors[YELLOW]);
			DrawString(1217, height - 40, width, height,"Pause-->", colors[YELLOW]);
		}
		else if(gamestate == Paused)												//making of play button...........
		{
			//Draw Play Symbol10+10+
			DrawTriangle( width-58,10,width-58,60 ,width-65+50,35, colors[ORANGE] );
			DrawString(1217, height - 40, width, height,"PLAY -->", colors[YELLOW]);
		}
		//Drawing Separator white line
		DrawRectangle(0,70,width,10,colors[AZURE]);
		
		//Drawing Border of yellow colour around candies Grid										//borders for candies
		DrawRectangle(0, 80 ,(15*70+14*10)+10+10 , 10 , colors[YELLOW]);
		DrawRectangle(0, 90 , 10 , 10*70+9*10 ,colors[YELLOW]);
		DrawRectangle(10+15*70+14*10 , 90 , 10 , 10*70+9*10 ,colors[YELLOW]);
		DrawRectangle(0 , 80+10 + (10*70+9*10),(15*70+14*10) + 10 + 10 , 10 ,colors[YELLOW]);

		//Drawing Hint Button														// drwaing hint button
		DrawString(15*70+14*10+20+30, height - 130 , width, height,"Hint", colors[YELLOW]);
		DrawCircle(15*70+14*10+20+50+100,120,20,colors[YELLOW]);
		DrawCircle(15*70+14*10+20+50+100,120,14,colors[RED]);
		
		//Drawing Mode Button															//Drawing Mode Button
		DrawString(15*70+14*10+20+30, height - 200 , width, height,"Levels", colors[YELLOW]);
		DrawCircle(levels_x,levels_y,20,colors[YELLOW]);
		DrawCircle(15*70+14*10+20+50+100,190,14,colors[RED]);
		//Drawing High score Button														//Drawing High score Button
		DrawString(15*70+14*10+20+30, height - 270 , width, height,"High", colors[YELLOW]);
		DrawString(15*70+14*10+20+30, height - 300 , width, height,"Score", colors[YELLOW]);
		DrawCircle(high_score_x,high_soore_y,20,colors[YELLOW]);
		DrawCircle(15*70+14*10+20+50+100,270,14,colors[RED]);
		//Drawing Menu Button															//Drawing Menu Button
		DrawString(15*70+14*10+20+30, height - 370 , width, height,"Settings", colors[YELLOW]);
		DrawCircle(settings_x,settings_y,20,colors[YELLOW]);
		DrawCircle(15*70+14*10+20+50+100,360,14,colors[RED]);
		
		//Drawing Load Button															//Drawing Load Button
		DrawString(15*70+14*10+20+30, height - 440 , width, height,"Load", colors[YELLOW]);
		DrawCircle(settings_x,430,20,colors[WHITE]);
		DrawCircle(15*70+14*10+20+50+100,430,14,colors[BLACK]);
		
		//Drawing Save Button															//Drawing Save Button
		DrawString(15*70+14*10+20+30, height - 510 , width, height,"Save", colors[YELLOW]);
		DrawCircle(settings_x,500,20,colors[WHITE]);
		DrawCircle(15*70+14*10+20+50+100,500,14,colors[BLACK]);
		
		
		
		DrawRectangle(15*70+14*10+20+50 , 550 , 80 , height - 550 -50 ,colors[PURPLE]);
		mygamemode->bar(score,height);
		
		
		DrawRectangle(15*70+14*10+20+40 , height - 50 , 100 , 30 , colors[ORANGE_RED]);
		DrawString(15*70+14*10+20+40, 30 , width, height,"Progress", colors[BLACK]);
		mygamemode->display();


}
void game :: save_game_state()									//code for saving game at a..............................
{
	ofstream myfile("highscore.txt");
	if(myfile.is_open())
	{
		for (int i = 0; i < 4; i++)
		{
			myfile << high_score[i];
			myfile << endl;
		}
		myfile.close();
	}

	myfile.open("game_state.txt");
	if(myfile.is_open())
	{
		//game mode
		myfile << gamemode << endl;
		//current level
		myfile << mygamemode->current_level << endl;
		
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 15; j++)
			{
				myfile << Array[i][j];
				myfile << " ";
			}
			myfile << endl;	
		}
		myfile.close();
	}
}
void game :: load_game_state() 											//play game from save file////////////////
{
	ifstream myfile("highscore.txt");
	if(myfile.is_open())
	{
		while(!myfile.eof())
		{

			for (int i = 0; i < 4; i++)
			{
				myfile >> high_score[i];
			}
		}
	}
	myfile.close();

	myfile.open("game_state.txt");
	if(myfile.is_open())
	{
		myfile >> gamemode;
		if(mygamemode != NULL)
		{
			delete mygamemode;
			mygamemode = NULL;
		}
		if(gamemode == 0)
		{	
			mygamemode = new normal_mode();
		}
		else
		{
			mygamemode = new time_trial_mode();
		}
		myfile >> mygamemode->current_level;
		
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 15; j++)
			{
				myfile >> Array[i][j];
			}
				
		}
		myfile.close();
	}
}
void game :: decorating_game_over()													//decorating game over
{
	DrawString(width / 2 - 80, height-330 , width, height,"GAME OVER ", colors[BLUE_VIOLET]);
	DrawString(width / 2 - 80, height-300 , width, height,"BETTER LUCK NECT TIME", colors[BLUE_VIOLET]);
	DrawString(width / 2 - 100, height-630, width, height,"Press Escape to exit", colors[GOLD]);
	DrawString(width / 2 - 100, height - 60, width, height,"FINAL SCORE:" + Num2Str(score), colors[ORANGE]);
   	DrawString(width / 2 - 100, height - 30, width, height,"GAME BY HANZLA SIBGHAT", colors[ORANGE]);
}
void game :: decorating_highscore()													//decorating highscore
{
	
	DrawString(width/3,height - height/6, width, height,"Top 4 High Scores",colors[BLUE]);
	
	DrawString(width/3, 2*height/3,width, height,"High Score 1 : " +Num2Str(high_score[0]),colors[BLUE]);
	DrawString(width/3, 2*height/3-40,width, height,"High Score 2 : " +Num2Str(high_score[1]),colors[BLUE]);
	DrawString(width/3, 2*height/3-80,width, height,"High Score 3 : " +Num2Str(high_score[2]),colors[BLUE]);
	DrawString(width/3, 2*height/3-120,width, height,"High Score 4 : " +Num2Str(high_score[3]),colors[BLUE]);

	DrawRectangle(width-70,0,70,70,colors[BROWN]);
	DrawString(width-70 + 10, height - 40 , width, height,"Back", colors[YELLOW]);
	DrawString(width / 2 - 100, height - 30, width, height,"GAME BY HANZLA SIBGHAT", colors[ORANGE]);
}
void game :: decorating_hint()
{


}
void game :: decorating_levels() 											//decorating levels................................
{
	DrawString(width/3,height - height/6, width, height,"Levels",colors[BLUE]);
	
	for (int i = 0; i < 3; i++)
	{
		if(i < mygamemode->current_level)
		{
			DrawRectangle(width/3 - 10,height/3 + i*40 - 25,100,40,colors[YELLOW]);
		}
		else if (i > mygamemode->current_level)
		{
			DrawRectangle(width/3 - 10,height/3 + i*40 - 25,100,40,colors[BROWN]);
		}
		
		DrawString(width/3, 2*height/3 - i*40,width , height,"Level : "+ Num2Str(i+1),colors[BLACK]);

	
	}
	
	
	
	
	
	DrawRectangle(width-70,0,70,70,colors[BROWN]);
	DrawString(width-70 + 10, height - 40 , width, height,"Back", colors[YELLOW]);
DrawString(width / 2 - 100, height - 30, width, height,"GAME BY HANZLA SIBGHAT", colors[ORANGE]);

}
void game :: decorating_player_profile()											//decorating profile.....................
{
	DrawString(width/3,height - height/6, width, height,"Player Profile",colors[BLUE]);
	
	char Temp_Array[100] = "Player name : ";
	strcat(Temp_Array,myplayer->player_name);
	DrawString(width/3, 2*height/3,width, height,Temp_Array,colors[BLUE]);
	DrawString(width/3, 2*height/3-40,width, height,"Player High Score : " + Num2Str(high_score[0]),colors[BLUE]);
	
	DrawRectangle(width-70,0,70,70,colors[BROWN]);
	DrawString(width-70 + 10, height - 40 , width, height,"Back", colors[YELLOW]);
DrawString(width / 2 - 100, height - 30, width, height,"GAME BY HANZLA SIBGHAT", colors[ORANGE]);
}
void game :: decorating_How_to_play()											//decorating HOW TO PLAY
{
	DrawString(width/4,height - 250, width, height,"How To Play",colors[BLUE]);
	
	DrawString(width/4, 400,width, height,"Normal Mode" ,colors[BLUE]);
	
	
	
	
	DrawString(width/4, 650*height/2-40,width, height,"Time Trial Mode ",colors[BLUE]);
	
	DrawRectangle(width-70,0,70,70,colors[BROWN]);
	DrawString(width-70 + 10, height - 40 , width, height,"Back", colors[YELLOW]);
DrawString(width / 2 - 100, height - 30, width, height,"GAME BY HANZLA SIBGHAT", colors[ORANGE]);
}
void game :: decorating_settings()										//decorating setting...........................
{
	DrawString(width/3,height - height/6, width, height,"Settings",colors[BLUE]);
	
	DrawString(width/3, 2*height/3,width, height,"Sound",colors[BLUE]);
	DrawCircle(width/3 + 200,height - 2*height/3 - 7,20,colors[YELLOW]);
	DrawCircle(width/3 + 200,height - 2*height/3 - 7,14,colors[RED]);
	
	DrawString(width/3, 2*height/3-40-10,width, height,"Music",colors[BLUE]);
	DrawCircle(width/3 + 200,height - 2*height/3 + 50- 7,20,colors[YELLOW]);
	DrawCircle(width/3 + 200,height - 2*height/3 + 50- 7,14,colors[RED]);
	
	DrawString(width/3, 2*height/3-80-20,width, height,"Player Profile",colors[BLUE]);
	DrawCircle(width/3 + 200 , height - 2*height/3 + 100- 7,20,colors[YELLOW]);
	DrawCircle(width/3 + 200 , height - 2*height/3 + 100- 7,14,colors[RED]);
	
	DrawString(width/3, 2*height/3-120-30,width, height,"How To PLay",colors[BLUE]);
	DrawCircle(width/3 + 200 , height - 2*height/3 + 150- 7,20,colors[YELLOW]);
	DrawCircle(width/3 + 200 , height - 2*height/3 + 150- 7,14,colors[RED]);
	
	
	DrawRectangle(width-70,0,70,70,colors[BROWN]);
	DrawString(width-70 + 10, height - 40 , width, height,"Back", colors[YELLOW]);
DrawString(width / 2 - 100, height - 30, width, height,"GAME BY HANZLA SIBGHAT", colors[ORANGE]);


}
void game :: decorating_main_menu()												//decorating mainmenu for the game
{
	DrawString(width/3,height - height/6, width, height,"Settings",colors[BLUE]);
	
	DrawString(width/3, 2*height/3,width, height,"Select Game_Mode",colors[BLUE]);
		
		if(gamestate == GameModeSelection)
		{
			int background_colour[2];
			background_colour[0] = BROWN;
			background_colour[1] = WHITE;
			int front_colour[2];
			front_colour[0] = WHITE;
			front_colour[1] = BLACK;
			
			int mode_colour[2];

			if(mygamemode->current_level == 0)
			{
				mode_colour[0] = 0;
				mode_colour[1] = 1;

			}
			else if(mygamemode ->current_level == 1)
			{
				mode_colour[0] = 1;
				mode_colour[1] = 0;
			}
			
			
			DrawString(width/3, 2*height/3-40-10,width, height,"Normal Mode",colors[YELLOW]);
			DrawCircle(width/3 + 300,height - 2*height/3 + 50- 7,20,colors[background_colour[mode_colour[0]]]);
			DrawCircle(width/3 + 300,height - 2*height/3 + 50- 7,14,colors[front_colour[mode_colour[0]]]);
			
			DrawString(width/3, 2*height/3-80-20,width, height,"Time Trial Mode",colors[YELLOW]);
			DrawCircle(width/3 + 300,height - 2*height/3 + 100- 7,20,colors[background_colour[mode_colour[1]]]);
			DrawCircle(width/3 + 300,height - 2*height/3 + 100- 7,14,colors[front_colour[mode_colour[1]]]);
		}
		else if(gamestate == MainMenu)		
		{
			DrawCircle(width/3 + 300,height - 2*height/3 - 7,20,colors[YELLOW]);
			DrawCircle(width/3 + 300,height - 2*height/3 - 7,14,colors[RED]);

			DrawString(width/3, 2*height/3-40-10,width, height,"Change Player Name",colors[BLUE]);
			DrawCircle(width/3 + 300,height - 2*height/3 + 50- 7,20,colors[YELLOW]);
			DrawCircle(width/3 + 300,height - 2*height/3 + 50- 7,14,colors[RED]);
			
		}
	DrawRectangle(width-70,0,70,70,colors[BROWN]);
	DrawString(width-70 + 10, height - 40 , width, height,"Back", colors[YELLOW]);
DrawString(width / 2 - 100, height - 30, width, height,"GAME BY HANZLA SIBGHAT", colors[ORANGE]);

	}
void game :: playgame()
{	
	glClearColor(0,0,0,0);													//  when game over it blancks the screen before printing something
	glClear (GL_COLOR_BUFFER_BIT);
	
	if(gamestate == Start)
	{
		//cout<<"Input Player Name"<<endl;
		//cin.getline(myplayer->player_name,100);
		gamestate = Ready;

	}
	else if(gamestate == Ready || gamestate == Paused)
	{  	
		decorating_game_screen();
		GetCookie(Array);
		autocrushing(Array);
		autofalling(Array);
		autofillingafterfalling(Array);
	}
	else if(gamestate == Game_Over)
	{
		decorating_game_over();
	}
	else if(gamestate == High_score)
	{
		decorating_highscore();
	}
	else if(gamestate == Levels)
	{
		decorating_levels();
	}
	else if(gamestate == Settings)
	{
		decorating_settings();
	}
	else if(gamestate == HowToPlay)
	{
		decorating_How_to_play();			
	}
	else if(gamestate == PlayerProfile)
	{
		decorating_player_profile();
	}
	else if(gamestate == MainMenu || gamestate == GameModeSelection)
	{
		decorating_main_menu();
	}

	glutSwapBuffers();

}
void game :: GetCookie(int Array[10][15])									// making of GEMS....................................
{    	
 	
	
	int fx = 10 ;
	int fy = 90 ;

	for(int i=0;i<10;i++)
	{ 
		for(int j=0;j<15;j++)
		{	
			DrawSquare(fx ,fy ,70,colors[BLACK]);
			
			if(Array[i][j]==0)
			 	DrawTriangle( fx+5, fy+50 , fx+60, fy+50 , fx+35 , fy+10, colors[ORANGE] );
			else if(Array[i][j]==1){
				DrawSquare(fx + 10 ,fy + 10 ,50,colors[GREEN]);
				DrawCircle(fx+35,fy+35,10,colors[BLACK]);}
			else if(Array[i][j]==2){
				DrawSquare(fx + 10 ,fy + 10,50,colors[PURPLE]);}
			else if(Array[i][j]==3){
				DrawCircle(fx+35,fy+35,25,colors[BLUE]);
				DrawSquare(fx + 28 ,fy + 28 ,15,colors[YELLOW]);}
			else if(Array[i][j]==4){
				DrawCircle(fx+35,fy+35,25,colors[RED]);
			}
			
			
			fx+=70;
			fx+=10;
		}
	fy+=70;
	fy+=10;
	fx=10;
	
	}

	
	
	


}
void game :: autofalling(int Array[10][15])                                 		//making of auto falling of gems.........................
{
	for(int i=9;i>=0;i--)
	{  	
		for(int j=0;j<15;j++)
		{ 
			if(Array[i][j]==8)
			{ for(int fill=i;fill<9;fill++)
				{
					int temp = Array[fill][j]; 
					Array[fill][j] = Array[fill+1][j];
					Array[fill+1][j] = temp;
				}
			}
		}
	}
}
void game :: autofillingafterfalling(int Ck[10][15])    					// making of auto filling from that place
{ 
	for(int row=0;row<10;row++)
	{  
		int col;
		for(col=0;col<15;col++)
		{ 
			if(Ck[row][col]==8)
			{      
				int Autofilled=Random();
				Ck[row][col]=Autofilled;   
			}
		}
	}
}
int game :: autocrushing(int Arr[10][15])								//autocraushing when in start gems match
{   int swapscore = 0;
	
	int temparray[10][15]; 
	for(int x=0;x<10;x++)
	{ 
		for(int y=0;y<15;y++)
		{  
			temparray[x][y]=Arr[x][y];
		}
	}


 //Comparison by rows and columns 
 	{
		for(int row=0;row<10;row++)
			for(int col=0;col<15;col++) 
			{ 
				int currentvalue = Arr[row][col];
				int valuesToCrushInRows = 0;
				int valuesToCrushInColumns = 0;
				//condition for columns	
				for (int j=col;j<15;j++)
				{
					if (currentvalue == Arr[row][j])
					{	valuesToCrushInColumns++;  }
					else
				{       break;	
				}
			}

	// Crush if greater than 2
	if (valuesToCrushInColumns > 2)
	{  for (int x=0;x<valuesToCrushInColumns;x++)
		{ //cout  << endl<< "crushing rox/col:" << row << "/" << (x+col) << "cuz x:" << x << "and current value:" << currentvalue << endl;
			temparray[row][x+col]=8;
			//swapscore++; 
		}
	}
	 //condition for rows
	for (int k=row;k<10;k++)
	{  if (currentvalue == Arr[k][col])
		{  valuesToCrushInRows++;  }
		else
		{  break;  }
	}

	// Crush if greater than 2
	if (valuesToCrushInRows > 2)
	{  for (int x=0;x<valuesToCrushInRows;x++)
		{ //cout  << endl<< "crushing rox/col:" << (row+x) << "/" << col << "cuz x:" << x << "and current value:" << currentvalue << endl;
			temparray[row+x][col]=8;
			//swapscore++;
		}
	}   
    } 
	//Copying all the elements of temp. array into the argument array to insure all the combinations in cross work as well 
	for(int i=0;i<10;i++)
	{ 
		for(int j=0;j<15;j++)
		{  
			Arr[i][j]=temparray[i][j];
			if(Arr[i][j]==8)
			{ 
				swapscore++;
			}
		}
	}
 	return swapscore; 
	      
}
     
}
void game :: mainstart(int Array[10][15])
{ 
	cout<<"Randomly Generated Array"<<endl;  
  	int rd,n; 
   	for(n=0;n<10;n++)
    { 	
		int m;
		for (m=0;m<15;m++)
		{
			rd=Random();      
			Array[n][m]=rd;
			cout<<Array[n][m]<<" ";
		}    
		cout<<endl;     
    }
}
void game :: swapping(int movedx,int movedy)												//SWAPPING
{      
	cout<<"Random numbers corresponding to both cells"<<endl;
	cout<<Array[clickx][clicky]<<","<<Array[movedx][movedy]<<endl;   
	//swapping function 
	int temp=Array[clickx][clicky]; 
	Array[clickx][clicky]=Array[movedx][movedy];
	Array[movedx][movedy]=temp;
	cout<<"Randomly swapped numbers corresponding to both cells"<<endl;
	cout<<Array[clickx][clicky]<<","<<Array[movedx][movedy]<<endl;
	//minimun 3 combinations exist At any Direction 
	cout<<"Swapped Array:"<<endl;
	int before[10][15];
	for(int i=0;i<10;i++)
	{
		for(int j=0;j<15;j++)
		{
			before[i][j]=Array[i][j]; 
			cout<<before[i][j]<<" ";
		}
		cout<<endl;
	}
	int swappingscore=autocrushing(Array);
	//bool answer=comparingArrays(before,Array);
	cout<<"Swapped Autocrushed Array:"<<endl;
	//Display Array
	
	score = (score+swappingscore) * mygamemode->multiplier[mygamemode->current_level];
	update_highscore();
	cout<<"Current Score"<<score<<endl; 
	if(swappingscore==0)
	{	
		playgame();
		//usleep(1*1000*1000*5);
		int temp1=Array[movedx][movedy];
		Array[movedx][movedy]=Array[clickx][clicky];
	        Array[clickx][clicky]=temp1;
		
		playgame();
		//usleep(1*1000*1000*5);

		cout<<"Swapping was not successful:swap back"<<endl;
		int before[10][15];
		for(int i=0;i<10;i++)
		{ 
			for(int j=0;j<15;j++)
		    {
				 before[i][j]=Array[i][j]; 
				cout<<before[i][j]<<" ";
			}
			cout<<endl;
		}
	}
}


